# Pre-Lifecycle Legacy

재구조화 이전 문서 보관 영역(조회 전용).
