# Operating Model (Low-Context First)

## Source-of-Truth Hierarchy
1. `docs/investigations/registry/active_stream_lock.yaml`
2. `docs/investigations/registry/project_flow_branching.md`
3. `docs/investigations/streams/<active>/ongoing.md`
4. `docs/investigations/registry/stream_registry.md`
5. `docs/investigations/registry/runlog_recent.md`
6. `docs/operations/RunLog.md`

## Protocol
- active 전환: lock -> registry -> ongoing 순서
- lifecycle: ongoing -> note/archive
- single-agent: 진행 중 결론은 gate 확인 전 확정 금지
