# __ACTIVE_STREAM__ Ongoing

## Quick Start
- objective:
  - __fill objective__
- must_run:
  - __fill command__
- must_check:
  - __fill artifact__
- optional:
  - __fill optional command__

## Scope
- __fill__

## Ongoing Tasks
| task_id | topic | status | next action | owner |
|---|---|---|---|---|
| T1 | __fill__ | ongoing | __fill__ | single-agent |
