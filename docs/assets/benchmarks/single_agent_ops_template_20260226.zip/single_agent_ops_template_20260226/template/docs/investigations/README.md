# __MODULE_NAME__ Investigations

운영 문서 canonical index.

## Structure
- `streams/<stream>/ongoing.md`
- `streams/<stream>/note.md`
- `streams/<stream>/archive/`
- `registry/*`
- `legacy/pre_lifecycle/`

## Registry
- `docs/investigations/registry/Rulebook_v0.md`
- `docs/investigations/registry/project_flow_branching.md`
- `docs/investigations/registry/stream_registry.md`
- `docs/investigations/registry/active_stream_lock.yaml`
- `docs/investigations/registry/agent_bootstrap.yaml`
- `docs/investigations/registry/operating_model.md`
- `docs/investigations/registry/runlog_recent.md`
- `docs/investigations/registry/decision_index.csv`
- `docs/investigations/registry/archive_index.csv`

## Fast Onboarding
1. `AGENTS.md`
2. `docs/investigations/registry/active_stream_lock.yaml`
3. `docs/investigations/registry/project_flow_branching.md`
4. `docs/investigations/streams/__ACTIVE_STREAM__/ongoing.md`
5. `docs/investigations/registry/runlog_recent.md`
