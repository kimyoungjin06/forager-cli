# __ACTIVE_STREAM__ Notes

## Accepted Decisions
- D1: __fill__
