# Stream Registry

| stream | purpose | status | active doc | note doc | archive dir |
|---|---|---|---|---|---|
| `phase0_quality` | source lock 이후 품질 개선 | standby | `docs/investigations/streams/phase0_quality/ongoing.md` | `docs/investigations/streams/phase0_quality/note.md` | `docs/investigations/streams/phase0_quality/archive/` |
| `__ACTIVE_STREAM__` | current priority stream | active | `docs/investigations/streams/__ACTIVE_STREAM__/ongoing.md` | `docs/investigations/streams/__ACTIVE_STREAM__/note.md` | `docs/investigations/streams/__ACTIVE_STREAM__/archive/` |
| `phase2_contract` | schema/coverage contract | standby | `docs/investigations/streams/phase2_contract/ongoing.md` | `docs/investigations/streams/phase2_contract/note.md` | `docs/investigations/streams/phase2_contract/archive/` |
| `phase3_release` | release tier/publish | standby | `docs/investigations/streams/phase3_release/ongoing.md` | `docs/investigations/streams/phase3_release/note.md` | `docs/investigations/streams/phase3_release/archive/` |

## Rules
- active stream은 1개만 유지
- 충돌 시 `active_stream_lock.yaml` 우선
