# __ACTIVE_STREAM__ Archive

미채택/보류/중단 문서 보관 폴더.
