# Single-Agent Operations Template (2026-02-26)

## Purpose
- 다른 프로젝트에 동일한 운영 방식(단일 SoT, 단일 active stream, lifecycle 문서관리)을 빠르게 적용하기 위한 템플릿.

## Included
- `template/docs/investigations/README.md`
- `template/docs/investigations/registry/*`
- `template/docs/investigations/streams/phase1_active/*`
- `template/docs/investigations/legacy/pre_lifecycle/README.md`

## Apply (Manual)
1. 대상 프로젝트에서 아래 경로를 생성한다.
- `docs/investigations/`
2. `template/docs/investigations/` 내용을 대상 `docs/investigations/`로 복사한다.
3. 플레이스홀더를 치환한다.
- `__MODULE_NAME__`, `__ACTIVE_STREAM__`, `__TAG__`
4. `registry/active_stream_lock.yaml`을 현재 프로젝트 상황에 맞게 수정한다.
5. 최초 반영 후 운영 로그에 1줄 기록한다.

## Apply (Script)
```bash
cd Export/single_agent_ops_template_20260226
./apply_template.sh <target_project_root> <module_name> <active_stream> <tag>
```

예시:
```bash
./apply_template.sh ~/Desktop/Workspace/MyProject twinpaper-gold phase1_active 2026-02-26
```

## Notes
- 이 템플릿은 규칙 중심(rule-first)이다.
- 자동화 스크립트/CI 결합은 프로젝트별로 후속 적용한다.
