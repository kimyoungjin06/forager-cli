#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 4 ]]; then
  cat <<'USAGE'
Usage:
  ./apply_template.sh <target_project_root> <module_name> <active_stream> <tag>

Example:
  ./apply_template.sh ~/Desktop/Workspace/MyProject twinpaper-gold phase1_active 2026-02-26
USAGE
  exit 1
fi

TARGET_ROOT="$1"
MODULE_NAME="$2"
ACTIVE_STREAM="$3"
TAG="$4"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$SCRIPT_DIR/template/docs/investigations"
DST_DIR="$TARGET_ROOT/docs/investigations"

mkdir -p "$DST_DIR"
rsync -a --delete "$SRC_DIR"/ "$DST_DIR"/

while IFS= read -r -d '' file; do
  sed -i \
    -e "s/__MODULE_NAME__/$MODULE_NAME/g" \
    -e "s/__ACTIVE_STREAM__/$ACTIVE_STREAM/g" \
    -e "s/__TAG__/$TAG/g" \
    "$file"
done < <(find "$DST_DIR" -type f -print0)

echo "Template applied:"
echo "  target: $TARGET_ROOT"
echo "  module: $MODULE_NAME"
echo "  active_stream: $ACTIVE_STREAM"
echo "  tag: $TAG"
echo "Next: open $DST_DIR/registry/active_stream_lock.yaml and adjust project-specific bootstrap paths."
